/* 
 * File:   tools.h
 * Author: Thais e Vitor
 *
 * Created on 25 de Novembro de 2018, 17:32
 */

#include "Lista.h"

#ifndef TOOLS_H
#define TOOLS_H

class Tools
{
    public:
        Tools(void);
        Lista getLista(char arquivo[], Lista lista);
    protected:
    
    private:
};

#endif /* TOOLS_H */

